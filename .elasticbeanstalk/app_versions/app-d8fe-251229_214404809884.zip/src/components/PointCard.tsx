import { Card, CardContent } from "./ui/card";

const PointCard = ({}) => {
  return (
    <Card>
      <CardContent>
        <div></div>
      </CardContent>
    </Card>
  );
};
export default PointCard;
